"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PasswordFormDialog from "@/components/password-form-dialog"
import UsersManagement from "@/components/users-management"
import AuditLogViewer from "@/components/audit-log-viewer"
import { encryptObject, decryptObject } from "@/lib/crypto"
import { initializeUsers } from "@/lib/user-manager"
import { addAuditLog } from "@/lib/audit-log"
import Image from "next/image"

type PasswordEntry = {
  id: string
  url: string
  username: string
  password: string
  createdAt: string
}

export default function DashboardClient() {
  const router = useRouter()
  const [passwords, setPasswords] = useState<PasswordEntry[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showPassword, setShowPassword] = useState<string | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingEntry, setEditingEntry] = useState<PasswordEntry | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("passwords")
  const [currentUser, setCurrentUser] = useState<string>("")

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated")
    if (!isAuthenticated) {
      router.push("/")
      return
    }

    const user = localStorage.getItem("adminUser") || "admin"
    setCurrentUser(user)

    initializeUsers()
    loadPasswords()
  }, [router])

  const loadPasswords = async () => {
    try {
      const encryptedData = localStorage.getItem("passwordEntries")
      if (encryptedData) {
        const decryptedPasswords = await decryptObject<PasswordEntry[]>(encryptedData)
        setPasswords(decryptedPasswords)
      }
    } catch (error) {
      console.error("Error al cargar contraseñas:", error)
      localStorage.removeItem("passwordEntries")
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("adminUser")
    router.push("/")
  }

  const handleSave = async (entry: PasswordEntry) => {
    let updatedPasswords: PasswordEntry[]
    let action: string
    let details: string

    if (editingEntry) {
      updatedPasswords = passwords.map((p) => (p.id === entry.id ? entry : p))
      action = "Editar Contraseña"
      details = `Contraseña editada para ${entry.url}`
      await addAuditLog(currentUser, action, "password", details, {
        url: entry.url,
        username: entry.username,
      })
    } else {
      updatedPasswords = [...passwords, entry]
      action = "Crear Contraseña"
      details = `Nueva contraseña agregada para ${entry.url}`
      await addAuditLog(currentUser, action, "password", details, {
        url: entry.url,
        username: entry.username,
      })
    }

    const encryptedData = await encryptObject(updatedPasswords)
    localStorage.setItem("passwordEntries", encryptedData)

    setPasswords(updatedPasswords)
    setEditingEntry(null)
  }

  const handleEdit = (entry: PasswordEntry) => {
    setEditingEntry(entry)
    setIsDialogOpen(true)
  }

  const handleAdd = () => {
    setEditingEntry(null)
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    const entryToDelete = passwords.find((p) => p.id === id)

    const updatedPasswords = passwords.filter((p) => p.id !== id)

    const encryptedData = await encryptObject(updatedPasswords)
    localStorage.setItem("passwordEntries", encryptedData)

    setPasswords(updatedPasswords)

    if (entryToDelete) {
      await addAuditLog(
        currentUser,
        "Eliminar Contraseña",
        "password",
        `Contraseña eliminada para ${entryToDelete.url}`,
        {
          url: entryToDelete.url,
          username: entryToDelete.username,
        },
      )
    }
  }

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text)
  }

  const filteredPasswords = passwords.filter(
    (p) =>
      p.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.username.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Cargando credenciales...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image src="/logo-acma.png" alt="DGMM ACMA Logo" width={48} height={48} className="drop-shadow-lg" />
            <div>
              <h1 className="text-xl font-bold text-white">Administrador de Contraseñas</h1>
              <p className="text-xs text-slate-400">DGMM - ACMA</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs text-green-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                />
              </svg>
              <span>Encriptado</span>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 text-sm text-slate-300 hover:text-white transition-colors"
            >
              Cerrar Sesión
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800 border border-slate-700">
            <TabsTrigger value="passwords" className="data-[state=active]:bg-slate-700">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
              Contraseñas
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-slate-700">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4h16z" />
              </svg>
              Usuarios
            </TabsTrigger>
            <TabsTrigger value="audit" className="data-[state=active]:bg-slate-700">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                />
              </svg>
              Bitácora
            </TabsTrigger>
          </TabsList>

          <TabsContent value="passwords" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">Credenciales Guardadas</h2>
                <p className="text-slate-400">
                  {passwords.length} {passwords.length === 1 ? "entrada" : "entradas"} registradas
                </p>
              </div>
              <Button onClick={handleAdd} className="bg-blue-600 hover:bg-blue-700">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Agregar Nueva
              </Button>
            </div>

            <div>
              <Input
                type="text"
                placeholder="Buscar por URL o usuario..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            {filteredPasswords.length === 0 ? (
              <Card className="border-slate-700 bg-slate-800/50">
                <CardContent className="py-12">
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-700 mb-4">
                      <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                        />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">
                      {searchTerm ? "No se encontraron resultados" : "No hay contraseñas guardadas"}
                    </h3>
                    <p className="text-slate-400 mb-6">
                      {searchTerm
                        ? "Intenta con otros términos de búsqueda"
                        : "Comienza agregando tu primera credencial"}
                    </p>
                    {!searchTerm && (
                      <Button onClick={handleAdd} className="bg-blue-600 hover:bg-blue-700">
                        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                        </svg>
                        Agregar Primera Credencial
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-slate-700 bg-slate-800/50">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700 hover:bg-slate-800/50">
                      <TableHead className="text-slate-300">URL del Sistema</TableHead>
                      <TableHead className="text-slate-300">Usuario</TableHead>
                      <TableHead className="text-slate-300">Contraseña</TableHead>
                      <TableHead className="text-slate-300">Fecha</TableHead>
                      <TableHead className="text-slate-300 text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPasswords.map((entry) => (
                      <TableRow key={entry.id} className="border-slate-700 hover:bg-slate-800/50">
                        <TableCell className="font-medium text-white">
                          <div className="flex items-center gap-2">
                            <svg
                              className="w-4 h-4 text-slate-400"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                              />
                            </svg>
                            <a
                              href={entry.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:text-blue-400 transition-colors"
                            >
                              {entry.url}
                            </a>
                          </div>
                        </TableCell>
                        <TableCell className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <span>{entry.username}</span>
                            <button
                              onClick={() => handleCopy(entry.username, "usuario")}
                              className="text-slate-500 hover:text-slate-300 transition-colors"
                              title="Copiar usuario"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                                />
                              </svg>
                            </button>
                          </div>
                        </TableCell>
                        <TableCell className="text-slate-300">
                          <div className="flex items-center gap-2">
                            <span className="font-mono">{showPassword === entry.id ? entry.password : "••••••••"}</span>
                            <button
                              onClick={() => setShowPassword(showPassword === entry.id ? null : entry.id)}
                              className="text-slate-500 hover:text-slate-300 transition-colors"
                              title={showPassword === entry.id ? "Ocultar" : "Mostrar"}
                            >
                              {showPassword === entry.id ? (
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                  />
                                </svg>
                              ) : (
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                                  />
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                  />
                                </svg>
                              )}
                            </button>
                            <button
                              onClick={() => handleCopy(entry.password, "contraseña")}
                              className="text-slate-500 hover:text-slate-300 transition-colors"
                              title="Copiar contraseña"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                                />
                              </svg>
                            </button>
                          </div>
                        </TableCell>
                        <TableCell className="text-slate-400 text-sm">
                          {new Date(entry.createdAt).toLocaleDateString("es-ES")}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(entry)}
                              className="text-slate-400 hover:text-white"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                />
                              </svg>
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(entry.id)}
                              className="text-red-400 hover:text-red-300 hover:bg-red-950/50"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                />
                              </svg>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="users">
            <UsersManagement />
          </TabsContent>

          <TabsContent value="audit">
            <AuditLogViewer />
          </TabsContent>
        </Tabs>
      </main>

      <PasswordFormDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSave={handleSave}
        editEntry={editingEntry}
      />
    </div>
  )
}
