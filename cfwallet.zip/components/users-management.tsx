"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import UserFormDialog from "@/components/user-form-dialog"
import { getUsers, createUser, updateUser, deleteUser, type AdminUser } from "@/lib/user-manager"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function UsersManagement() {
  const [users, setUsers] = useState<AdminUser[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [currentUser, setCurrentUser] = useState<string>("")

  useEffect(() => {
    const user = localStorage.getItem("adminUser") || "admin"
    setCurrentUser(user)
    loadUsers()
  }, [])

  const loadUsers = async () => {
    setIsLoading(true)
    const loadedUsers = await getUsers()
    setUsers(loadedUsers)
    setIsLoading(false)
  }

  const handleSave = async (userData: { id?: string; username: string; password: string }) => {
    let result

    if (userData.id) {
      const updates: Partial<AdminUser> = { username: userData.username }
      if (userData.password) {
        updates.password = userData.password
      }
      result = await updateUser(userData.id, updates, currentUser)
    } else {
      result = await createUser(userData.username, userData.password, currentUser)
    }

    if (result.success) {
      setMessage({ type: "success", text: userData.id ? "Usuario actualizado" : "Usuario creado exitosamente" })
      await loadUsers()
      setEditingUser(null)
      setTimeout(() => setMessage(null), 3000)
    } else {
      setMessage({ type: "error", text: result.error || "Error al guardar usuario" })
      setTimeout(() => setMessage(null), 3000)
    }
  }

  const handleEdit = (user: AdminUser) => {
    setEditingUser(user)
    setIsDialogOpen(true)
  }

  const handleAdd = () => {
    setEditingUser(null)
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("¿Estás seguro de eliminar este usuario?")) return

    const result = await deleteUser(id, currentUser)

    if (result.success) {
      setMessage({ type: "success", text: "Usuario eliminado" })
      await loadUsers()
      setTimeout(() => setMessage(null), 3000)
    } else {
      setMessage({ type: "error", text: result.error || "Error al eliminar usuario" })
      setTimeout(() => setMessage(null), 3000)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Cargando usuarios...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Usuarios Administradores</h2>
          <p className="text-slate-400">
            {users.length} {users.length === 1 ? "usuario" : "usuarios"} registrados
          </p>
        </div>
        <Button onClick={handleAdd} className="bg-blue-600 hover:bg-blue-700">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Agregar Usuario
        </Button>
      </div>

      {message && (
        <Alert variant={message.type === "error" ? "destructive" : "default"} className="bg-slate-800 border-slate-700">
          <AlertDescription>{message.text}</AlertDescription>
        </Alert>
      )}

      <Card className="border-slate-700 bg-slate-800/50">
        <Table>
          <TableHeader>
            <TableRow className="border-slate-700 hover:bg-slate-800/50">
              <TableHead className="text-slate-300">Usuario</TableHead>
              <TableHead className="text-slate-300">Fecha de Creación</TableHead>
              <TableHead className="text-slate-300">Último Acceso</TableHead>
              <TableHead className="text-slate-300 text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id} className="border-slate-700 hover:bg-slate-800/50">
                <TableCell className="font-medium text-white">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-sm">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                    {user.username}
                  </div>
                </TableCell>
                <TableCell className="text-slate-300">
                  {new Date(user.createdAt).toLocaleDateString("es-ES", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </TableCell>
                <TableCell className="text-slate-300">
                  {user.lastLogin
                    ? new Date(user.lastLogin).toLocaleDateString("es-ES", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "Nunca"}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(user)}
                      className="text-slate-400 hover:text-white"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                        />
                      </svg>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(user.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-950/50"
                      disabled={users.length === 1}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                        />
                      </svg>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <UserFormDialog open={isDialogOpen} onOpenChange={setIsDialogOpen} onSave={handleSave} editUser={editingUser} />
    </div>
  )
}
