// Gestión de usuarios administradores
import { encryptObject, decryptObject } from "./crypto"
import { addAuditLog } from "./audit-log"

export type AdminUser = {
  id: string
  username: string
  password: string
  createdAt: string
  lastLogin?: string
}

const USERS_STORAGE_KEY = "admin_users"

// Inicializar con usuario por defecto si no existe
export async function initializeUsers(): Promise<void> {
  const existingUsers = localStorage.getItem(USERS_STORAGE_KEY)

  if (!existingUsers) {
    const defaultUser: AdminUser = {
      id: crypto.randomUUID(),
      username: "admin",
      password: "admin123",
      createdAt: new Date().toISOString(),
    }

    const encryptedUsers = await encryptObject([defaultUser])
    localStorage.setItem(USERS_STORAGE_KEY, encryptedUsers)
  }
}

// Obtener todos los usuarios
export async function getUsers(): Promise<AdminUser[]> {
  try {
    const encryptedData = localStorage.getItem(USERS_STORAGE_KEY)
    if (!encryptedData) {
      await initializeUsers()
      return await getUsers()
    }

    return await decryptObject<AdminUser[]>(encryptedData)
  } catch (error) {
    console.error("Error al cargar usuarios:", error)
    return []
  }
}

// Validar credenciales de usuario
export async function validateUser(username: string, password: string): Promise<AdminUser | null> {
  const users = await getUsers()
  const user = users.find((u) => u.username === username && u.password === password)

  if (user) {
    // Actualizar último login
    user.lastLogin = new Date().toISOString()
    await saveUsers(users)

    await addAuditLog(username, "Inicio de Sesión", "auth", "Usuario inició sesión exitosamente")
  } else {
    await addAuditLog(username || "desconocido", "Intento Fallido", "auth", "Intento de inicio de sesión fallido")
  }

  return user || null
}

// Guardar usuarios
async function saveUsers(users: AdminUser[]): Promise<void> {
  const encryptedData = await encryptObject(users)
  localStorage.setItem(USERS_STORAGE_KEY, encryptedData)
}

// Crear nuevo usuario
export async function createUser(
  username: string,
  password: string,
  createdBy: string,
): Promise<{ success: boolean; error?: string }> {
  const users = await getUsers()

  // Verificar si el usuario ya existe
  if (users.some((u) => u.username === username)) {
    return { success: false, error: "El usuario ya existe" }
  }

  const newUser: AdminUser = {
    id: crypto.randomUUID(),
    username,
    password,
    createdAt: new Date().toISOString(),
  }

  users.push(newUser)
  await saveUsers(users)

  await addAuditLog(createdBy, "Crear Usuario", "user", `Nuevo usuario creado: ${username}`, {
    newUsername: username,
  })

  return { success: true }
}

// Actualizar usuario
export async function updateUser(
  id: string,
  updates: Partial<AdminUser>,
  updatedBy: string,
): Promise<{ success: boolean; error?: string }> {
  const users = await getUsers()
  const index = users.findIndex((u) => u.id === id)

  if (index === -1) {
    return { success: false, error: "Usuario no encontrado" }
  }

  const oldUsername = users[index].username

  // Si se está actualizando el username, verificar que no exista
  if (updates.username && updates.username !== users[index].username) {
    if (users.some((u) => u.username === updates.username)) {
      return { success: false, error: "El nombre de usuario ya existe" }
    }
  }

  users[index] = { ...users[index], ...updates }
  await saveUsers(users)

  const details = updates.password
    ? `Contraseña actualizada para usuario: ${oldUsername}`
    : `Usuario actualizado: ${oldUsername}${updates.username ? ` → ${updates.username}` : ""}`

  await addAuditLog(updatedBy, "Actualizar Usuario", "user", details, {
    userId: id,
    oldUsername,
    newUsername: updates.username,
  })

  return { success: true }
}

// Eliminar usuario
export async function deleteUser(id: string, deletedBy: string): Promise<{ success: boolean; error?: string }> {
  const users = await getUsers()

  // No permitir eliminar si es el único usuario
  if (users.length === 1) {
    return { success: false, error: "No puedes eliminar el único usuario administrador" }
  }

  const userToDelete = users.find((u) => u.id === id)

  const filteredUsers = users.filter((u) => u.id !== id)
  await saveUsers(filteredUsers)

  if (userToDelete) {
    await addAuditLog(deletedBy, "Eliminar Usuario", "user", `Usuario eliminado: ${userToDelete.username}`, {
      deletedUsername: userToDelete.username,
    })
  }

  return { success: true }
}
