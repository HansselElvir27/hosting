// Utilidad para encriptar y desencriptar datos sensibles
// Usa AES-GCM con Web Crypto API

const ENCRYPTION_KEY_NAME = "password_manager_key"

// Genera o recupera la clave de encriptación
async function getEncryptionKey(): Promise<CryptoKey> {
  const keyData = localStorage.getItem(ENCRYPTION_KEY_NAME)

  if (keyData) {
    const rawKey = Uint8Array.from(atob(keyData), (c) => c.charCodeAt(0))
    return await crypto.subtle.importKey("raw", rawKey, { name: "AES-GCM" }, false, ["encrypt", "decrypt"])
  }

  // Generar nueva clave si no existe
  const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"])

  const exportedKey = await crypto.subtle.exportKey("raw", key)
  const keyString = btoa(String.fromCharCode(...new Uint8Array(exportedKey)))
  localStorage.setItem(ENCRYPTION_KEY_NAME, keyString)

  return key
}

// Encripta un string
export async function encrypt(text: string): Promise<string> {
  const key = await getEncryptionKey()
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const encodedText = new TextEncoder().encode(text)

  const encryptedData = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encodedText)

  const encryptedArray = new Uint8Array(encryptedData)
  const combined = new Uint8Array(iv.length + encryptedArray.length)
  combined.set(iv)
  combined.set(encryptedArray, iv.length)

  return btoa(String.fromCharCode(...combined))
}

// Desencripta un string
export async function decrypt(encryptedText: string): Promise<string> {
  try {
    const key = await getEncryptionKey()
    const combined = Uint8Array.from(atob(encryptedText), (c) => c.charCodeAt(0))

    const iv = combined.slice(0, 12)
    const data = combined.slice(12)

    const decryptedData = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data)

    return new TextDecoder().decode(decryptedData)
  } catch (error) {
    console.error("Error al desencriptar:", error)
    throw new Error("No se pudo desencriptar los datos")
  }
}

// Encripta un objeto completo
export async function encryptObject<T>(obj: T): Promise<string> {
  const jsonString = JSON.stringify(obj)
  return await encrypt(jsonString)
}

// Desencripta un objeto
export async function decryptObject<T>(encryptedText: string): Promise<T> {
  const jsonString = await decrypt(encryptedText)
  return JSON.parse(jsonString)
}
