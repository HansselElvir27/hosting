import { encryptObject, decryptObject } from "./crypto"

export type AuditLogEntry = {
  id: string
  timestamp: string
  user: string
  action: string
  category: "auth" | "password" | "user"
  details: string
  metadata?: Record<string, any>
}

const AUDIT_LOG_KEY = "audit_log"

// Agregar entrada al log de auditoría
export async function addAuditLog(
  user: string,
  action: string,
  category: "auth" | "password" | "user",
  details: string,
  metadata?: Record<string, any>,
): Promise<void> {
  try {
    const logs = await getAuditLogs()

    const newEntry: AuditLogEntry = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      user,
      action,
      category,
      details,
      metadata,
    }

    logs.unshift(newEntry) // Agregar al inicio para mostrar los más recientes primero

    // Limitar a 1000 entradas para no sobrecargar el storage
    const limitedLogs = logs.slice(0, 1000)

    const encryptedData = await encryptObject(limitedLogs)
    localStorage.setItem(AUDIT_LOG_KEY, encryptedData)
  } catch (error) {
    console.error("Error al guardar log de auditoría:", error)
  }
}

// Obtener todos los logs
export async function getAuditLogs(): Promise<AuditLogEntry[]> {
  try {
    const encryptedData = localStorage.getItem(AUDIT_LOG_KEY)
    if (!encryptedData) {
      return []
    }

    return await decryptObject<AuditLogEntry[]>(encryptedData)
  } catch (error) {
    console.error("Error al cargar logs de auditoría:", error)
    return []
  }
}

// Limpiar logs antiguos (opcional)
export async function clearOldLogs(daysToKeep = 90): Promise<void> {
  try {
    const logs = await getAuditLogs()
    const cutoffDate = new Date()
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep)

    const filteredLogs = logs.filter((log) => new Date(log.timestamp) > cutoffDate)

    const encryptedData = await encryptObject(filteredLogs)
    localStorage.setItem(AUDIT_LOG_KEY, encryptedData)
  } catch (error) {
    console.error("Error al limpiar logs antiguos:", error)
  }
}
