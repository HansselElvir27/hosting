import LoginForm from "@/components/login-form"
import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="w-full max-w-md px-6">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center mb-6">
            <Image
              src="/logo-acma.png"
              alt="DGMM ACMA Logo"
              width={120}
              height={120}
              className="drop-shadow-2xl"
              priority
            />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Administrador de Contraseñas</h1>
          <p className="text-slate-400">DGMM - Departamento de Análisis y Control Marítimo</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
