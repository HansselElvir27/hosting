import DashboardClient from "@/components/dashboard-client"

export default function DashboardPage() {
  return <DashboardClient />
}
